package ca.usherbrooke.argyll.argyll;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Function extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_function);

        Button tiroir_button = findViewById(R.id.tiroir_button);
        Button claw_button = findViewById(R.id.claw_button);
        Button ice_cube_button = findViewById(R.id.ice_cube_button);
        Button homing_button = findViewById(R.id.homing_button);

        tiroir_button.setOnClickListener(this);
        claw_button.setOnClickListener(this);
        ice_cube_button.setOnClickListener(this);
        homing_button.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {

            case R.id.tiroir_button:
                openTiroirActivity();
                break;

            case R.id.claw_button:
                openClawActivity();
                break;

            case R.id.ice_cube_button:
                openIceCubeActivity();
                break;

            case R.id.home_textView:
                openHomeActivity();
                break;
        }
    }

    public void openTiroirActivity()
    {
        Intent intent = new Intent(this, Tiroir.class);
        startActivity(intent);
    }
    public void openClawActivity()
    {
        Intent intent = new Intent(this, Claw.class);
        startActivity(intent);
    }
    public void openIceCubeActivity()
    {
        Intent intent = new Intent(this, IceCube.class);
        startActivity(intent);
    }
    public void openHomeActivity()
    {
        Intent intent = new Intent(this, Home.class);
        startActivity(intent);
    }
}
