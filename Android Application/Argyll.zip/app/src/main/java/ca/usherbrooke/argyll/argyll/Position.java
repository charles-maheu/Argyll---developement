package ca.usherbrooke.argyll.argyll;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Position extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_position);

        Button motor_button = findViewById(R.id.motors_button);
        Button saved_position_button = findViewById(R.id.saved_positions_button);

        motor_button.setOnClickListener(this);
        saved_position_button.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {

            case R.id.motors_button:
                openMotorActivity();
                break;

            case R.id.saved_positions_button:
                openSavedPositionActivity();
                break;
        }
    }

    public void openMotorActivity()
    {
        Intent intent = new Intent(this, Motor.class);
        startActivity(intent);
    }
    public void openSavedPositionActivity()
    {
        Intent intent = new Intent(this, SavedPositions.class);
        startActivity(intent);
    }
}
