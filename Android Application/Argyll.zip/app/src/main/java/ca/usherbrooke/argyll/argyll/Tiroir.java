package ca.usherbrooke.argyll.argyll;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Tiroir extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tiroir);
    }
}
