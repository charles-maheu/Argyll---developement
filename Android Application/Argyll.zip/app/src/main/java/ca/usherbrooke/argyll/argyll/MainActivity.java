package ca.usherbrooke.argyll.argyll;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button positions_button = findViewById(R.id.saved_positions_button);
        Button functions_button = findViewById(R.id.functions_button);

        positions_button.setOnClickListener(this);
        functions_button.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {

            case R.id.saved_positions_button:
                openPositionActivity();
                break;

            case R.id.functions_button:
                openFunctionActivity();
                break;
        }
    }

    public void openPositionActivity()
    {
        Intent intent = new Intent(this, Position.class);
        startActivity(intent);
    }
    public void openFunctionActivity()
    {
        Intent intent = new Intent(this, Function.class);
        startActivity(intent);
    }
}
