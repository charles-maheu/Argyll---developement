package ca.usherbrooke.argyll.argyll;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Motor1 extends AppCompatActivity implements View.OnTouchListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motor1);

        Button motor1_down_button = findViewById(R.id.motor1_down_button);
        Button motor1_up_button = findViewById(R.id.motor1_up_button);

        motor1_down_button.setOnTouchListener(this);
        motor1_up_button.setOnTouchListener(this);

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        TextView motor1_value = findViewById(R.id.motor1_value);
        switch (v.getId())
        {
            case R.id.motor1_down_button:
                moveDown(motor1_value);
                break;

            case R.id.motor1_up_button:
                moveUp(motor1_value);
                break;
        }
        return true;
    }

    public void moveDown(TextView motor_value)
    {
        int value = Integer.parseInt(motor_value.getText().toString());
        if (value > -180 && value <= 180)
        {
            value -= 1;
            motor_value.setText(String.valueOf(value));
        }
    }

    public void moveUp(TextView motor_value)
    {
        int value = Integer.parseInt(motor_value.getText().toString());
        if (value >= -180 && value < 180)
        {
            value += 1;
            motor_value.setText(String.valueOf(value));
        }
    }

}
