package ca.usherbrooke.argyll.argyll;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Motor extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motor);

        Button motor1_button = findViewById(R.id.motor1_button);
        Button motor2_button = findViewById(R.id.motor2_button);
        Button motor3_button = findViewById(R.id.motor3_button);
        Button motor4_button = findViewById(R.id.motor4_button);
        Button position_saving_button = findViewById(R.id.position_saving_button);

        motor1_button.setOnClickListener(this);
        motor2_button.setOnClickListener(this);
        motor3_button.setOnClickListener(this);
        motor4_button.setOnClickListener(this);
        position_saving_button.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.motor1_button:
                openMotor1Activity();
                break;

            case R.id.motor2_button:
                openMotor2Activity();
                break;

            case R.id.motor3_button:
                openMotor3Activity();
                break;

            case R.id.motor4_button:
                openMotor4Activity();
                break;

            case R.id.position_saving_button:
                Toast toast = Toast.makeText(this, "Position enregistrée", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                toast.show();
                break;
        }
    }

    public void openMotor1Activity()
    {
        Intent intent = new Intent(this, Motor1.class);
        startActivity(intent);
    }
    public void openMotor2Activity()
    {
        Intent intent = new Intent(this, Motor2.class);
        startActivity(intent);
    }
    public void openMotor3Activity()
    {
        Intent intent = new Intent(this, Motor3.class);
        startActivity(intent);
    }
    public void openMotor4Activity()
    {
        Intent intent = new Intent(this, Motor4.class);
        startActivity(intent);
    }
}
