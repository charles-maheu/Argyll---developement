package ca.usherbrooke.argyll.argyll;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.concurrent.TimeUnit;

public class SavedPositions extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_positions);

        Button position_1_button = findViewById(R.id.position_1_button);
        Button position_2_button = findViewById(R.id.position_2_button);
        Button position_3_button = findViewById(R.id.position_3_button);
        Button position_4_button = findViewById(R.id.position_4_button);
        Button position_5_button = findViewById(R.id.position_5_button);
        Button position_6_button = findViewById(R.id.position_6_button);
        Button position_7_button = findViewById(R.id.position_7_button);
        Button position_8_button = findViewById(R.id.position_8_button);
        Button position_9_button = findViewById(R.id.position_9_button);

        position_1_button.setOnClickListener(this);
        position_2_button.setOnClickListener(this);
        position_3_button.setOnClickListener(this);
        position_4_button.setOnClickListener(this);
        position_5_button.setOnClickListener(this);
        position_6_button.setOnClickListener(this);
        position_7_button.setOnClickListener(this);
        position_8_button.setOnClickListener(this);
        position_9_button.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.position_1_button:
                goToPosition(1);
                break;

            case R.id.position_2_button:
                goToPosition(2);
                break;

            case R.id.position_3_button:
                goToPosition(3);
                break;

            case R.id.position_4_button:
                goToPosition(4);
                break;

            case R.id.position_5_button:
                goToPosition(5);
                break;

            case R.id.position_6_button:
                goToPosition(6);
                break;

            case R.id.position_7_button:
                goToPosition(7);
                break;

            case R.id.position_8_button:
                goToPosition(8);
                break;

            case R.id.position_9_button:
                goToPosition(9);
                break;
        }
    }

    public void goToPosition(int P)
    {
        String position = "Position"+ P;
        showToast(position);
    }

    private Toast mToastToShow;
    public void showToast(String str) {
        // Set the toast and duration
        int toastDurationInMilliSeconds = 700;
        mToastToShow = Toast.makeText(this, str, Toast.LENGTH_SHORT);
        mToastToShow.setGravity(Gravity.CENTER_VERTICAL, 0, 0);

        // Set the countdown to display the toast
        CountDownTimer toastCountDown;
        toastCountDown = new CountDownTimer(toastDurationInMilliSeconds, 1000 /*Tick duration*/) {
            public void onTick(long millisUntilFinished) {
                mToastToShow.show();
            }
            public void onFinish() {
                mToastToShow.cancel();
            }
        };

        // Show the toast and starts the countdown
        mToastToShow.show();
        toastCountDown.start();
    }
}
