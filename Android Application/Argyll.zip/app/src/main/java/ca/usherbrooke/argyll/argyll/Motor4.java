package ca.usherbrooke.argyll.argyll;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Motor4 extends AppCompatActivity implements View.OnTouchListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motor4);

        Button motor4_down_button = findViewById(R.id.motor4_down_button);
        Button motor4_up_button = findViewById(R.id.motor4_up_button);

        motor4_down_button.setOnTouchListener(this);
        motor4_up_button.setOnTouchListener(this);

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        TextView motor4_value = findViewById(R.id.motor4_value);
        switch (v.getId())
        {
            case R.id.motor4_down_button:
                moveDown(motor4_value);
                break;

            case R.id.motor4_up_button:
                moveUp(motor4_value);
                break;
        }
        return true;
    }

    public void moveDown(TextView motor_value)
    {
        int value = Integer.parseInt(motor_value.getText().toString());
        if (value > -180 && value <= 180)
        {
            value -= 1;
            motor_value.setText(String.valueOf(value));
        }
    }

    public void moveUp(TextView motor_value)
    {
        int value = Integer.parseInt(motor_value.getText().toString());
        if (value >= -180 && value < 180)
        {
            value += 1;
            motor_value.setText(String.valueOf(value));
        }
    }

}
